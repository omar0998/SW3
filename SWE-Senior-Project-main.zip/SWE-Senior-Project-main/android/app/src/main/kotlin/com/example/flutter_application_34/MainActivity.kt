package com.example.flutter_application_34

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
