
import 'package:flutter/material.dart';
// import 'dart:ui' ;
import '../controllers/services/cloud_functions_service.dart';

/*
Model: Manages the data and logic of the application.
It represents the state of the application and defines how that state can be manipulated.
encapsulating data and business rules, ensuring the integrity and consistency of the application state.

Some Usual Tasks:

-- Data Management:
---- Store and manipulate information that the app needs to function.

-- Business Logic:
---- Implement business rules, logic and APIs calls .

-- Notify Changes:
---- Notify listeners about changes in the state using notifyListeners() or other mechanisms.
Allow other parts of the application to react to changes in the data.

*/
// WaterBill
class WaterBills extends ChangeNotifier {
  List<WaterBill> listOfWaterBills = [];
  bool flag = true;

  // WaterBills(listOfWaterBills);

// retrieveAllBillsOfSEC
// retrieveBillsSummaryOfSEC
  Future<void> retrieveAllBillsOfNWC() async {

  if(flag){
      flag=false;
    // Your request payload
    Map<String, dynamic> reqJsonData = {
      'homeID': 'TESTHEVQmTnDYNZjBiSj',
    };

    final resJsonData = await callCloudFunctionWithJsonBody(
    "retrieveAllBillsOfNWC",
      reqJsonData
    );
    
    print(resJsonData);
    print(resJsonData['data']);

    for( Map<String,dynamic> record in resJsonData['data'] ){

    WaterBill waterBill =  WaterBill();


    waterBill.accountNumber = record['account_number'];
    waterBill.invoiceDate = DateTime.fromMillisecondsSinceEpoch(
        record['invoice_date']['_seconds'] * 1000 +
        -5 + record['invoice_date']['_nanoseconds'] ~/ 1000000,
        isUtc: true,
    );
      waterBill.invoiceDate = DateTime.fromMillisecondsSinceEpoch(
      record['period_start']['_seconds'] * 1000 +
      -5 + record['period_start']['_nanoseconds'] ~/ 1000000,
      isUtc: true,
    );
      waterBill.invoiceDate = DateTime.fromMillisecondsSinceEpoch(
      record['period_end']['_seconds'] * 1000 +
      -5 + record['period_end']['_nanoseconds'] ~/ 1000000,
      isUtc: true,
    );
    waterBill.invoiceNumber = record['invoice_number'];
    waterBill.numberOfDays = record['number_of_days'];
    waterBill.waterConsumptionQuantity = record['water_consumption_quantity_(m^3)'];
    waterBill.waterPreviousMeterReading = record['water_previous_meter_reading'];
    waterBill.waterCurrentMeterReading = record["water_current_meter_reading"];
    waterBill.readingMethod = record['reading_method'];
    waterBill.waterConsumptionValue = record["water_consumption_value_(sar)"];
    waterBill.wasteServiceValue = record['waste_service_value_(sar)'].toDouble();
    waterBill.waterConsumptionSlabsDetails = record['water_consumption_slabs_details'];
    waterBill.serviceFee = record["service_fee_(sar)"].toDouble() ;
    waterBill.totalValueBeforeVat = record["total_value_before_vat_(sar)"].toDouble();
    waterBill.vat = record["vat_(sar)"].toDouble();
    waterBill.totalValueAfterVat = record["total_value_after_vat_(sar)"];
    
    listOfWaterBills.add(waterBill);

    }
    print("listOfWaterBills");
    print(listOfWaterBills);
    notifyListeners();

    }

}
}

class WaterBill {


  late String _accountNumber = "1";
  late DateTime _invoiceDate =  DateTime(2023,1,1);
  late String _invoiceNumber = "0";
  late DateTime _periodEnd =  DateTime(2023,1,1);
  late DateTime _periodStart =  DateTime(2023,1,1);
  late int _numberOfDays = 30;
  late double _waterConsumptionQuantity = 0.0;
  late double _waterPreviousMeterReading = 0;
  late double _waterCurrentMeterReading = 0;
  late String _readingMethod = "Actual";
  late Map<String,dynamic> _waterConsumptionSlabsDetails = {"first_slab":9.0,'second_slab':17.4};
  late double _waterConsumptionValue = 0.0;
  late double _wasteServiceValue = 0.0;
  late double _serviceFee = 5.0;
  late double _totalValueBeforeVat = 0.0;
  late double _vat = 0.0;
  late double _totalValueAfterVat = 0.0;

  WaterBill();

  String get accountNumber => _accountNumber ;
  DateTime get invoiceDate => _invoiceDate ;
  String get invoiceNumber => _invoiceNumber ;
  DateTime get periodEnd => _periodEnd ;
  DateTime get periodStart => _periodStart ;
  int get numberOfDays => _numberOfDays;
  double get waterConsumptionQuantity => _waterConsumptionQuantity ;
  double get waterPreviousMeterReading => _waterPreviousMeterReading ;
  double get waterCurrentMeterReading =>  _waterCurrentMeterReading ;
  String get readingMethod => _readingMethod ;
  Map<String,dynamic> get waterConsumptionSlabsDetails => _waterConsumptionSlabsDetails ;
  double get waterConsumptionValue  => _waterConsumptionValue ;
  double get wasteServiceValue  => _wasteServiceValue ;
  double get serviceFee =>  _serviceFee;
  double get totalValueBeforeVat =>  _totalValueBeforeVat; 
  double get vat => _vat;
  double get totalValueAfterVat =>  _totalValueAfterVat ;

  set accountNumber(String newValue) => _accountNumber = newValue;
  set invoiceDate(DateTime newValue) => _invoiceDate = newValue;
  set invoiceNumber(String newValue) => _invoiceNumber = newValue;
  set periodEnd(DateTime newValue) => _periodEnd = newValue;
  set periodStart(DateTime newValue) => _periodStart = newValue;
  set numberOfDays(int newValue) => _numberOfDays = newValue;
  set waterConsumptionQuantity(double value)=>_waterConsumptionQuantity = value;
  set waterPreviousMeterReading(double value) =>  _waterPreviousMeterReading = value;
  set waterCurrentMeterReading(double value) =>  _waterCurrentMeterReading = value;
  set readingMethod(String value) =>  _readingMethod = value;
  set waterConsumptionSlabsDetails(Map<String, dynamic> value) =>  _waterConsumptionSlabsDetails = value;
  set waterConsumptionValue(double value) => _waterConsumptionValue = value;
  set wasteServiceValue(double value) =>_wasteServiceValue = value;
  set serviceFee(double newValue) => _serviceFee = newValue;
  set totalValueBeforeVat(double newValue) => _totalValueBeforeVat = newValue;
  set vat(double newValue) => _vat = newValue;
  set totalValueAfterVat(double newValue) => _totalValueAfterVat = newValue;

  }

