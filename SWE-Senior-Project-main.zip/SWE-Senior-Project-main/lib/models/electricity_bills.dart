
import 'package:flutter/material.dart';
// import 'dart:ui' ;
import '../controllers/services/cloud_functions_service.dart';

/*
Model: Manages the data and logic of the application.
It represents the state of the application and defines how that state can be manipulated.
encapsulating data and business rules, ensuring the integrity and consistency of the application state.

Some Usual Tasks:

-- Data Management:
---- Store and manipulate information that the app needs to function.

-- Business Logic:
---- Implement business rules, logic and APIs calls .

-- Notify Changes:
---- Notify listeners about changes in the state using notifyListeners() or other mechanisms.
Allow other parts of the application to react to changes in the data.

*/
// electricityBill
class ElectricityBills extends ChangeNotifier {
  List<ElectricityBill> listOfElectricityBills = [];
  bool flag = true;

  // ElectricityBills(listOfElectricityBills);

// retrieveAllBillsOfSEC
// retrieveBillsSummaryOfSEC
  Future<void> retrieveAllBillsOfSEC() async {

    if(flag){
      flag=false;
    // Your request payload
    Map<String, dynamic> reqJsonData = {
      'homeID': 'TESTHEVQmTnDYNZjBiSj',
    };

    final resJsonData = await callCloudFunctionWithJsonBody(
    "retrieveAllBillsOfSEC",
      reqJsonData
    );
    
    print(resJsonData);
    print(resJsonData['data']);

    for( Map<String,dynamic> record in resJsonData['data'] ){

     ElectricityBill electricityBill =  ElectricityBill();

    electricityBill._invoiceDate = DateTime.fromMillisecondsSinceEpoch(
        record['invoice_date']['_seconds'] * 1000 +
        -10 + record['invoice_date']['_nanoseconds'] ~/ 1000000,
        isUtc: true,
    );

    electricityBill.numberOfDays = record['number_of_days'];
    electricityBill.consumptionQuantity = record['consumption_quantity_(kWh)'];
    electricityBill.previousMeterReading = record['previous_meter_reading'];
    electricityBill.currentMeterReading = record["current_meter_reading"];
    electricityBill.multiplicationFactor = record["multiplication_factor"];
    electricityBill.consumptionValue = record["consumption_value_(sar)"];
    print(record["service_fee"].runtimeType);
    electricityBill.serviceFee = record["service_fee"].toDouble() ;
    electricityBill._totalValueBeforeVat = record["total_value_before_vat_(sar)"];
    electricityBill.vat = record["vat_(sar)"];
    electricityBill._totalValueAfterVat = record["total_value_after_vat_(sar)"];

    listOfElectricityBills.add(electricityBill);

    }
    print("listOfElectricityBills");
    print(listOfElectricityBills);
    notifyListeners();

    }

}
}

class ElectricityBill {

  late DateTime _invoiceDate =  DateTime(2023,1,1);
  late int _numberOfDays = 30;
  late int _consumptionQuantity = 0;
  late int _previousMeterReading = 0;
  late int _currentMeterReading = 0;
  late int _multiplicationFactor = 1;
  late double _consumptionValue = 0.0;
  late double _serviceFee = 10.0;
  late double _totalValueBeforeVat = 0.0;
  late double _vat = 0.0;
  late double _totalValueAfterVat = 0.0;

  ElectricityBill();

  DateTime get invoiceDate => _invoiceDate ;
  int get numberOfDays => _numberOfDays;
  int get consumptionQuantity => _consumptionQuantity ;
  int get previousMeterReading => _previousMeterReading ;
  int get currentMeterReading =>  _currentMeterReading ;
  int get multiplicationFactor  =>  _multiplicationFactor ;
  double get consumptionValue  => _consumptionValue ;
  double get serviceFee =>  _serviceFee;
  double get totalValueBeforeVat =>  _totalValueBeforeVat; 
  double get vat => _vat;
  double get totalValueAfterVat =>  _totalValueAfterVat ;


  set invoiceDate(DateTime newValue) => _invoiceDate = newValue;
  set numberOfDays(int newValue) => _numberOfDays = newValue;
  set consumptionQuantity(int newValue) => _consumptionQuantity = newValue;
  set previousMeterReading(int newValue) => _previousMeterReading = newValue;
  set currentMeterReading(int newValue) => _currentMeterReading = newValue;
  set multiplicationFactor(int newValue) => _multiplicationFactor = newValue;
  set consumptionValue(double newValue) => _consumptionValue = newValue;
  set serviceFee(double newValue) => _serviceFee = newValue;
  set totalValueBeforeVat(double newValue) => _totalValueBeforeVat = newValue;
  set vat(double newValue) => _vat = newValue;
  set totalValueAfterVat(double newValue) => _totalValueAfterVat = newValue;

  }

