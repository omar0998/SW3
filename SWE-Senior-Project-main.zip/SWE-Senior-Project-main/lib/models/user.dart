import 'package:flutter/foundation.dart';

class User extends ChangeNotifier{

  final String _userName = 'Turki';

  String get userName => _userName;

//     notifyListeners(); // Notify listeners about the change

}