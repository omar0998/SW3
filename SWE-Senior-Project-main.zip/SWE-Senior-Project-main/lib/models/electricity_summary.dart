
import 'package:flutter/material.dart';
// import 'dart:ui' ;



class ElecricitySummary extends ChangeNotifier {
  
  final DateTime _invoice_date =  DateTime(2023,1,1);
  final int number_of_days = 30;
  final int _consumption_quantity = 0;
  final int _previous_meter_reading = 0;
  final int _current_meter_reading = 0;
  final int multiplication_factor = 1;
  final double _consumption_value = 0.0;
  final double _service_fee = 10.0;
  final double _total_value_before_vat = 0.0;
  final double _vat = 0.0;
  final double _total_value_after_vat = 0.0;

  ElecricitySummary();
}

// See this

// import 'package:flutterflow_ui/flutterflow_ui.dart';
// import 's_e_c_page_widget.dart' show SECPageWidget;
// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:google_fonts/google_fonts.dart';
// import 'package:provider/provider.dart';

// class SECPageModel extends FlutterFlowModel<SECPageWidget> {
//   ///  State fields for stateful widgets in this page.

//   final unfocusNode = FocusNode();

//   /// Initialization and disposal methods.

//   void initState(BuildContext context) {}

//   void dispose() {
//     unfocusNode.dispose();
//   }

//   /// Action blocks are added here.

//   /// Additional helper methods are added here.
// }

