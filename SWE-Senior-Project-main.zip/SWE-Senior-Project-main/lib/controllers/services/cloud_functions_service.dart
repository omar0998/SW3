// firebase_functions.dart

import 'dart:convert'; // Import for JSON encoding
import 'package:http/http.dart' as http;

Future<Map<String, dynamic>> callCloudFunctionWithJsonBody(String fucntionName,Map<String, dynamic> jsonData ) async {
  try {
   
    // Your Cloud Function URL
    String functionUrl = 'https://us-central1-swe-senior-project.cloudfunctions.net/$fucntionName';

    print(functionUrl);
    
    print(jsonData);
    // Make a POST request to your Cloud Function
    final response = await http.post(
      Uri.parse(functionUrl),
      headers: {
        'Content-Type': 'application/json',
      },
      body: jsonEncode(jsonData),
    );

    // print(response.body);    
    // print('Type of response: ${response.runtimeType}');
    // print('Type of response.body: ${response.body.runtimeType}');
    // print('Type of response.body: ${jsonDecode(response.body).runtimeType}');
    // print(jsonDecode(response.body));

  
    // Handle the response
    if (response.statusCode == 200) {
      print('Success: ${response.body}');
      return jsonDecode(response.body);
    } else {
      print('Error: ${response.statusCode}, ${response.body}');
      return {"error":"Error: ${response.statusCode}, ${response.body}"};
    }

  } // on FirebaseFunctionsException catch (error) {
  //   print("error?");
  //   print(error.code);
  //   print(error.details);
  //   print(error.message);
  // } 
  catch (e) {
      print('Error calling Cloud Function: $e');
      return {"error":"Error calling Cloud Function: $e"};
  }
}

// see this:

// import 'package:flutter/material.dart';

// /// A service that stores and retrieves user settings.
// ///
// /// By default, this class does not persist user settings. If you'd like to
// /// persist the user settings locally, use the shared_preferences package. If
// /// you'd like to store settings on a web server, use the http package.
// class SettingsService {
//   /// Loads the User's preferred ThemeMode from local or remote storage.
//   Future<ThemeMode> themeMode() async => ThemeMode.system;

//   /// Persists the user's preferred ThemeMode to local or remote storage.
//   Future<void> updateThemeMode(ThemeMode theme) async {
//     // Use the shared_preferences package to persist settings locally or the
//     // http package to persist settings over the network.
//   }
// }




// ------------------------------------------ For Unkown Reason this way doesn't work:

// Future<void> callCloudFunctionWithJsonBody(String fucntionName, String jsonData ) async {
//   try {
//     print("callCloudFunctionWithJsonBody");
//     final HttpsCallable callable = FirebaseFunctions.instance.httpsCallable(
//       "retrieveBillsSummaryOfSEC", 
//     );

//     print(jsonData);
//     print( jsonEncode({"homeID": "TESTHEVQmTnDYNZjBiSj"}));
//  final result = await callable.call(
//   jsonEncode({"homeID": "TESTHEVQmTnDYNZjBiSj"}));

//   final dynamic responseData = result.data;

//   // Check if the response indicates success or failure
//     if (responseData != null && responseData['statusCode'] != null) {
//       final int statusCode = responseData['statusCode'];
//       print('HTTP Status Code: $statusCode');

//       // Handle the response data based on the status code
//       if (statusCode >= 200 && statusCode < 300) {
//         // Successful response
//         print('Response Data: $responseData');
//       } else {
//         // Handle error based on status code
//         print('Error: $statusCode - ${responseData['error']}');
//       }
//     } else {
//       print('Unexpected response format: $responseData');
//     }


//   // print(result.toString());
//   // final dynamic responseData = result.data;
//   // // Handle the data based on its type
//   // if (responseData is String) {
//   //   // Handle String data
//   //   print('String data: $responseData');
//   // } else if (responseData is Map<String, dynamic>) {
//   //   // Handle Map data
//   //   print('Map data: $responseData');
//   // } else {
//   //   // Handle other types as needed
//   //   print('Unexpected data type: $responseData');
//   // }

//   // final dynamic response = result.data;
//   // final List<dynamic> dataList = response[0];

//   // print(dataList.toString());
//     // Handle the result
//     // print('Result: ${jsonDecode(result.data)}');

//   } 
  
//   on FirebaseFunctionsException catch (error) {
//     print("error?");
//   print(error.code);
//   print(error.details);
//   print(error.message);
  
//   } catch (e) {
//     // Handle errors
//       print('Error calling Cloud Function: $e');
//   }
// }