import 'package:cloud_firestore/cloud_firestore.dart';


class FirestoreService {
  final CollectionReference homes = FirebaseFirestore.instance.collection('Home');

  Future<void> addHomeRecord({
    required String homeID,
    required String homeName,
    required String billID,
    required String amount,
    required Timestamp dueDate,
    required bool isPaid,
    required String serviceID,
    required String userID,
    required String usageRecordID,
    required double consumptionAmount,
  }) async {
    try {
      DocumentReference homeDocRef = await homes.add({
        'HomeID': homeID,
        'HomeName': homeName,
      });

      await _addSubcollectionRecord(homeDocRef, 'Bill', {
        'BillID': billID,
        'Amount': amount,
        'DueDate': dueDate,
        'IsPaid': isPaid,
        'ServiceID': serviceID,
        'UserID': userID,
      });

      await _addSubcollectionRecord(homeDocRef, 'Consumption', {
        'UsageRecordID': usageRecordID,
        'ConsumptionAmount': consumptionAmount,
        'ServiceID': serviceID,
        'Timestamp': FieldValue.serverTimestamp(),
        'UserID': userID,
      });

      print('Home record added successfully.');
    } catch (e) {
      print('Error adding home record: $e');
    }
  }

  Future<void> _addSubcollectionRecord(
    DocumentReference parentDocRef,
    String subcollectionName,
    Map<String, dynamic> data,
  ) async {
    CollectionReference subcollection = parentDocRef.collection(subcollectionName);
    await subcollection.add(data);
  }
}

  // final CollectionReference users = FirebaseFirestore.instance.collection('users');
  // 
  // Future<void> updateUserName(String userId, String newName) async {
  //   try {
  //     // Get the document reference for the user with the specified userId
  //     DocumentReference userRef = users.doc(userId);

  //     // Update the 'name' field in the user document
  //     await userRef.update({'name': newName});

  //     // Accessing a subcollection
  //     CollectionReference userSubcollection = userRef.collection('posts');
      
  //     // Perform operations on the subcollection
  //     await userSubcollection.add({'title': 'New Post', 'content': 'This is the content'});

  //     print('User name updated successfully.');
  //   } catch (e) {
  //     print('Error updating user name: $e');
  //   }
  // }

