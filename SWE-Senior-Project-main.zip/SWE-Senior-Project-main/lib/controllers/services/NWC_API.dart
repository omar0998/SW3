import 'dart:convert';
import 'dart:io';

import 'package:http_interceptor/http_interceptor.dart';

class HttpClient {

  static Future<void> fetchData(InterceptedClient client) async {
    var parsedData;
    try {
      final response =
          await client.get('https://ebranch.nwc.com.sa/Arabic/Pages/Login.aspx'.toUri());
      
      print(response.statusCode);
      if (response.statusCode == 200) {
        parsedData = json.decode(response.body);
        // print("response: " + parsedData);
      } else {
        return Future.error(
          "Error while fetching.",
          StackTrace.fromString(response.body),
        );
      }
    } on SocketException {
      return Future.error('No Internet connection 😑');
    } on FormatException {
      return Future.error('Bad response format 👎');
    } on Exception catch (error) {
      print(error);
      return Future.error('Unexpected error 😢');
    }

  }

  /// implement http request with this client
}