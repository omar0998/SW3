import 'package:flutter/material.dart';
import 'package:flutter_app/models/electricity_bills.dart';
import 'package:flutter_app/models/electricity_summary.dart';
import 'package:flutter_app/views/electricity_view.dart';
import 'package:flutter_app/views/home_view.dart';

/*
Controller: Handles user input, updates the Model, and communicates with the View.
is focused on user interactions and application flow.

Some Usual Tasks:

-- Handle User Input:
---- Receive and process user input from the View and trigger appropriate actions.

-- Update Model:
---- Interact with the Model to update the application state.

-- Communicate Between Model and View:
---- Act as an intermediary between the Model and the View. 
---- Update the View when the Model changes and vice versa.
*/



class ElectricityController with ChangeNotifier {
  final ElectricityBills _electricityBillsModel = ElectricityBills();
  // late ElecricitySummary _elecricitySummaryModel;
  int _currIndex = 0;
  bool _loading = false;


  bool get loading => _loading;
  ElectricityBills get electricityBillsModel => _electricityBillsModel;
  int get currIndex => _currIndex;


  set currIndex(int newValue) => _currIndex = newValue;
  set loading(bool value) {
    _loading = value;
    notifyListeners();
  }

  Future<void> navigateToElectricityView(BuildContext context) async {
    // Show circular indicator
    showCircularIndicator(context);

    // Wait for the data retrieval to complete
    await _electricityBillsModel.retrieveAllBillsOfSEC();

    // Data retrieval is complete, hide circular indicator
    hideCircularIndicator(context);

    // Now you can navigate to the next screen
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ElectricityView(),
      ),
    );
   
  }
  //------------------------------ Helper Methods ------------------------------

  // Method to show circular indicator
  void showCircularIndicator(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return Center(
          child: CircularProgressIndicator(
            valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF58C4BB)),
          ),
        );
      },
    );
  }

  // Method to hide circular indicator
  void hideCircularIndicator(BuildContext context) {
    Navigator.of(context).pop(); // Close the dialog
  }

    
  void nextIndex(){
    int maxIndex = _electricityBillsModel.listOfElectricityBills.length-1;

    if(!(_currIndex+1>maxIndex)){
      _currIndex++;
    }
    notifyListeners();
  }

  void prevIndex(){
    int minIndex = 0;
    if(!(_currIndex-1<minIndex)){
      _currIndex--;
    }
    notifyListeners();
   } 

}
