import 'package:flutter/material.dart';
import 'package:flutter_app/views/electricity_view.dart';
import 'package:flutter_app/views/water_view.dart';
import 'package:flutter_app/views/tmp_water_view.dart';
import 'package:provider/provider.dart';

/*
Controller: Handles user input, updates the Model, and communicates with the View.
is focused on user interactions and application flow.

Some Usual Tasks:

-- Handle User Input:
---- Receive and process user input from the View and trigger appropriate actions.

-- Update Model:
---- Interact with the Model to update the application state.

-- Communicate Between Model and View:
---- Act as an intermediary between the Model and the View. 
---- Update the View when the Model changes and vice versa.
*/

import 'package:provider/provider.dart';

class HomeController extends ChangeNotifier {
  String _appBarTitle = "AA";
  set appBarTitle(String newValue) => _appBarTitle = newValue;
  String get appBarTitle => _appBarTitle;
  // void navigateToElectricityView(BuildContext context) {
  //   const SECAcount = true;
  //   if (SECAcount) {
  //     // Use Navigator to push a new MaterialPageRoute
  //     Navigator.push(
  //       context,
  //       MaterialPageRoute(
  //         builder: (context) => ElecricityView(),
  //       ),
  //     );
  //     ChangeNotifier();
  //   } else {
  //     //show error message
  //   }
  // }

  // void navigateToWaterView(BuildContext context) {
  //   const SECAcount = true;
  //   if (SECAcount) {
  //     // Use Navigator to push a new MaterialPageRoute
  //     Navigator.push(
  //       context,
  //       MaterialPageRoute(
  //         builder: (context) => WaterView(),
  //       ),
  //     );
  //     ChangeNotifier();
  //   } else {
  //     //show error message
  //   }
  // }
}
