import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_app/controllers/electricity_controller.dart';
import 'package:flutter_app/controllers/water_controller.dart';
import 'package:flutter_app/firebase_options.dart';
import 'package:flutter_app/models/user.dart';
import 'package:flutter_app/views/auth_page.dart';
import 'package:flutter_app/views/home_view.dart';
import 'package:provider/provider.dart';

void main() async {
  
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  runApp(const MyApp());
}

/// The Widget that configures your application.
class MyApp extends StatelessWidget {
  const MyApp({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return 
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (context) => ElectricityController()),
        ChangeNotifierProvider(create: (context) => WaterController()),

        ChangeNotifierProvider(create: (context) => User()),// << With NotifyListnear()

        // Provider(create: (context) => AnotherProvider()), << No NotifyListnear() !
        // Add more providers as needed
      ],
      child: MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter App',
      theme: ThemeData(
        useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple).copyWith(background: Colors.white),
      ),
      home: ChangeNotifierProvider(
        create: (context) => User(),
        child: const HomeView(),
      )
      ));
      

  }
}
