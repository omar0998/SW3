import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_charts/charts.dart';
import 'package:intl/intl.dart';

// void main() {
//   runApp(const MyApp());
// }

// class MyApp extends StatelessWidget {
//   const MyApp({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       title: 'Flutter Demo',
//       theme: ThemeData(
//         colorScheme:
//             ColorScheme.fromSeed(seedColor: Color.fromARGB(255, 49, 95, 157)),
//         useMaterial3: true,
//       ),
//       home: const MyHomePage(title: 'Electricity Statistics Page'),
//     );
//   }
// }

class MyHomePage extends StatelessWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  Widget build(BuildContext context) {
    final List<ElectricityData> chartData = [
      ElectricityData(DateTime.parse('2023-01-20 20:18:04Z'), 35),
      ElectricityData(DateTime.parse('2023-09-20 20:18:04Z'), 28),
      ElectricityData(DateTime.parse('2023-10-20 20:18:04Z'), 34),
      ElectricityData(DateTime.parse('2023-11-20 20:18:04Z'), 32),
      ElectricityData(DateTime.parse('2024-01-20 20:18:04Z'), 40),
      ElectricityData(DateTime.parse('2024-02-20 20:18:04Z'), 100)
    ];

    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Padding(
              padding: EdgeInsets.only(right: 15, left: 5),
              child: SfCartesianChart(
                primaryXAxis: DateTimeAxis(
                  dateFormat: DateFormat.yMMM(),
                  majorGridLines: const MajorGridLines(width: 0),
                  labelRotation: 45,
                  intervalType: DateTimeIntervalType.months,
                  interval: 1,
                  rangePadding: ChartRangePadding.none,
                  // edgeLabelPlacement: EdgeLabelPlacement.shift
                ),
                primaryYAxis: const NumericAxis(
                  labelFormat: '{value}kWH',
                  majorGridLines: MajorGridLines(width: 0),
                ),
                series: <CartesianSeries>[
                  LineSeries<ElectricityData, DateTime>(
                    dataSource: chartData,
                    xValueMapper: (ElectricityData consumption, _) =>
                        consumption.date,
                    yValueMapper: (ElectricityData consumption, _) =>
                        consumption.consumption,
                    markerSettings: const MarkerSettings(isVisible: true),
                    color: Color.fromARGB(255, 17, 148, 188),
                  )
                ],
              )),
        ],
      ),
    );
  }
}

class ElectricityData {
  ElectricityData(this.date, this.consumption);
  final DateTime date;
  final double consumption;
}
