import 'package:flutter/material.dart';

class MyTextfiled extends StatelessWidget {
  // ignore: prefer_typing_uninitialized_variables
  final TextEditingController controller;
  final String hinttext;
  final bool obsecur;
  const MyTextfiled(
      {super.key,
      required this.controller,
      required this.hinttext,
      required this.obsecur});
  @override
  Widget build(context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 25.0),
      child: TextField(
        controller: controller,
        obscureText: obsecur,
        decoration: InputDecoration(
          enabledBorder: const OutlineInputBorder(
            borderSide: BorderSide(color: Colors.white),
          ),
          focusedBorder: const OutlineInputBorder(
            borderSide: BorderSide(
              color: Color.fromARGB(255, 150, 147, 147),
            ),
          ),
          fillColor: const Color.fromARGB(255, 248, 244, 244),
          filled: true,
          hintText: hinttext,
        ),
      ),
    );
  }
}