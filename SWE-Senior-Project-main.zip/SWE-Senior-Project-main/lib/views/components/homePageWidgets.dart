import 'package:firebase_auth/firebase_auth.dart' as f;
import 'package:flutter/material.dart';
import 'package:flutter_app/controllers/electricity_controller.dart';
import 'package:flutter_app/controllers/water_controller.dart';
import 'package:provider/provider.dart';
import '../../controllers/home_controller.dart';
import 'package:flutter_app/models/user.dart';
import 'package:flutter_svg/flutter_svg.dart';

class MyHomePageTopPicture extends StatelessWidget {
  void signUserOut() {
    f.FirebaseAuth.instance.signOut();
  }

  @override
  Widget build(BuildContext context) {
    var homeController = Provider.of<HomeController>(context);
    // Access the userModel using Provider
    var userModel = Provider.of<User>(context);
    Size screenSize = MediaQuery.of(context).size;
    double width = screenSize.width;
    double height = screenSize.height;
    return Container(
      // that contains the container of top bar
      width: MediaQuery.of(context).size.width * 1, // 80% of the screen width
      height:
          MediaQuery.of(context).size.height * 0.22, // 60% of the screen height
      margin: const EdgeInsets.only(
        // 5% of the screen width
        bottom: 10, // 2.5% of the screen height
      ),
      child: Stack(
        children: [
          Container(
            // that contains the picture
            width: MediaQuery.of(context).size.width *
                1, // 80% of the screen width
            height: MediaQuery.of(context).size.height *
                0.28, // 60% of the screen height
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                begin: Alignment(0.71, -0.71),
                end: Alignment(-0.71, 0.71),
                colors: [Color(0xFF5BC0DE), Color(0xFF53C98A)],
              ),
              borderRadius: BorderRadius.circular(7),
              border: const Border(
                left: BorderSide(
                  strokeAlign: BorderSide.strokeAlignCenter,
                  color: Color(0xFFE9E9E9),
                ),
                top: BorderSide(
                  strokeAlign: BorderSide.strokeAlignCenter,
                  color: Color(0xFFE9E9E9),
                ),
                right: BorderSide(
                  strokeAlign: BorderSide.strokeAlignCenter,
                  color: Color(0xFFE9E9E9),
                ),
                bottom: BorderSide(
                  width: 0.75,
                  strokeAlign: BorderSide.strokeAlignCenter,
                  color: Color(0xFFE9E9E9),
                ),
              ),
            ),
          ),
          Container(
              alignment: Alignment.bottomLeft,
              padding:
                  EdgeInsets.only(left: width * 0.05, bottom: height * 0.01),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    userModel.userName,
                    // "Yousef",
                    style: TextStyle(
                      color: Color(0xFFF2F3ED),
                      fontSize: 32,
                      fontFamily: 'Plus Jakarta Sans',
                      fontWeight: FontWeight.w300,
                    ),
                  ),
                  IconButton(
                    onPressed: signUserOut,
                    icon: const Icon(Icons.logout),
                  ),
                ],
              )),
        ],
      ),
    );
  }
}

class MyHomePageBills extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    var electricityController =
        Provider.of<ElectricityController>(context, listen: false);
    var waterController = Provider.of<WaterController>(context, listen: false);

    // Access the userModel using Provider
    var userModel = Provider.of<User>(context);
    Size screenSize = MediaQuery.of(context).size;
    double width = screenSize.width;
    double height = screenSize.height;

    return Container(
      width: // that containes the bills
          width * 1, // 80% of the screen width
      height: height * 0.18, // 60% of the screen height
      margin: EdgeInsets.only(
        // 5% of the screen width
        // right: width * 0.01,
        // left: width * 0.01,
        bottom: height * 0.01, // 2.5% of the screen height
      ),
      decoration: ShapeDecoration(
        color: Colors.white,
        shape: RoundedRectangleBorder(
          side: BorderSide(width: 0.50, color: Color(0x19222222)),
          borderRadius: BorderRadius.circular(10),
        ),
      ),
      child: Column(
        children: [
          Container(
            alignment: Alignment.centerLeft,
            margin: EdgeInsets.all(width * 0.03),
            child: Text(
              'Bills',
              style: TextStyle(
                color: Color(0xFF333333),
                fontSize: 24,
                fontFamily: 'Plus Jakarta Sans',
                fontWeight: FontWeight.w300,
                height: 1,
              ),
            ),
          ),
          Row(children: [
            Container(
              //Blue Square
              margin: EdgeInsets.only(right: width * 0.03, left: width * 0.02),
              width: width * 0.45,
              height: height * 0.10,
              // alignment: Alignment.centerLeft,

              decoration: ShapeDecoration(
                color: Color(0xFFB3CFF1),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                shadows: const [
                  BoxShadow(
                    color: Color(0x19161616),
                    blurRadius: 10.47,
                    offset: Offset(0, 2.62),
                    spreadRadius: 0,
                  )
                ],
              ),
              //The Details of blue
              child: Stack(
                children: [
                  GestureDetector(onTap: () {
                    // electricityController.navigateToElectricityView(context);
                    waterController.navigateToWaterView(context);
                  }),
                  Row(
                    children: [
                      Container(
                          width: width * 0.14,
                          height: height * 0.10,
                          child: Container(
                              padding: EdgeInsets.all(height * 0.015),
                              width: width * 0.12,
                              height: height * 0.8,
                              child: SvgPicture.asset('assets/nwc-Logo.svg'))),
                      Container(
                          height: height * 0.075,
                          child: VerticalDivider(
                            width: width * 0.03,
                            color: Color.fromARGB(142, 134, 133, 133),
                            thickness: 1,
                          )),
                      Container(
                        padding: EdgeInsets.only(left: width * 0.01),
                        width: width * 0.28,
                        height: height * 0.10,
                        alignment: Alignment.center,
                        child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Container(
                                  width: width * 0.30,
                                  alignment: Alignment.centerLeft,
                                  child: const Text(
                                    'Dec 23 ',
                                    style: TextStyle(
                                      color: Color(0xFF555555),
                                      fontSize: 15,
                                      fontFamily: 'Inter',
                                      fontWeight: FontWeight.w200,
                                    ),
                                  )),
                              Row(children: [
                                Container(
                                  child: const Text(
                                    '213.95',
                                    style: TextStyle(
                                      color: Color(0xFF555555),
                                      fontSize: 20,
                                      fontFamily: 'Inter',
                                      fontWeight: FontWeight.w300,
                                    ),
                                  ),
                                ),
                                Container(
                                  padding: EdgeInsets.only(top: height * 0.008),
                                  alignment: Alignment.bottomCenter,
                                  child: const Text(
                                    'SAR',
                                    style: TextStyle(
                                      color: Color(0xFF555555),
                                      fontSize: 10,
                                      fontFamily: 'Inter',
                                      fontWeight: FontWeight.w400,
                                      height: 0.17,
                                    ),
                                  ),
                                )
                              ])
                            ]),
                      )
                    ],
                  )
                ],
              ),
            ),
            Container(
                //Orange Square
                width: width * 0.45,
                height: height * 0.10,
                margin: EdgeInsets.only(left: width * 0.01, right: 0.03),
                // alignment: Alignment.centerRight,

                decoration: ShapeDecoration(
                  color: Color(0xFFFFCE5C),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  shadows: const [
                    BoxShadow(
                      color: Color(0x19161616),
                      blurRadius: 10.47,
                      offset: Offset(0, 2.62),
                      spreadRadius: 0,
                    )
                  ],
                ),
                //Make the orange square click routs to SEC+ The Orange Details

                child: Stack(
                  children: [
                    GestureDetector(
                        onTap: () {
                          electricityController
                              .navigateToElectricityView(context);
                        },
                        child: Row(
                          children: [
                            Container(
                                width: width * 0.14,
                                height: height * 0.10,
                                child: Container(
                                  padding: EdgeInsets.all(height * 0.015),
                                  width: width * 0.12,
                                  height: height * 0.8,
                                  child:
                                      SvgPicture.asset('assets/sec-logo.svg'),
                                )),
                            Container(
                                height: height * 0.075,
                                child: VerticalDivider(
                                  width: width * 0.03,
                                  color: Color.fromARGB(142, 134, 133, 133),
                                  thickness: 1,
                                )),
                            Container(
                              padding: EdgeInsets.only(left: width * 0.01),
                              width: width * 0.28,
                              height: height * 0.10,
                              alignment: Alignment.center,
                              child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Container(
                                        width: width * 0.30,
                                        alignment: Alignment.centerLeft,
                                        child: const Text(
                                          'Dec 23 ',
                                          style: TextStyle(
                                            color: Color(0xFF555555),
                                            fontSize: 15,
                                            fontFamily: 'Inter',
                                            fontWeight: FontWeight.w200,
                                          ),
                                        )),
                                    Row(children: [
                                      Container(
                                        child: const Text(
                                          '213.95',
                                          style: TextStyle(
                                            color: Color(0xFF555555),
                                            fontSize: 20,
                                            fontFamily: 'Inter',
                                            fontWeight: FontWeight.w300,
                                          ),
                                        ),
                                      ),
                                      Container(
                                        padding: EdgeInsets.only(
                                            top: height * 0.008),
                                        alignment: Alignment.bottomCenter,
                                        child: const Text(
                                          'SAR',
                                          style: TextStyle(
                                            color: Color(0xFF555555),
                                            fontSize: 10,
                                            fontFamily: 'Inter',
                                            fontWeight: FontWeight.w400,
                                            height: 0.17,
                                          ),
                                        ),
                                      )
                                    ])
                                  ]),
                            )
                          ],
                        ))
                  ],
                )),
            Container()
          ]),
        ],
      ),
    );
  }
}

class MyHomePageServices extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    double width = screenSize.width;
    double height = screenSize.height;
    return Container(
      //Contain all elements
      width: width,
      height: height * 0.31,
      margin: EdgeInsets.only(
        // 5% of the screen width
        right: width * 0.01,
        left: width * 0.01,
        bottom: height * 0.01, // 2.5% of the screen height
      ),
      decoration: ShapeDecoration(
        color: Colors.white,
        shape: RoundedRectangleBorder(
          side: const BorderSide(width: 0.50, color: Color(0x19222222)),
          borderRadius: BorderRadius.circular(5),
        ),
      ),
      child: Column(
        children: [
          Container(
            alignment: Alignment.centerLeft,
            margin: EdgeInsets.all(width * 0.03),
            child: Text(
              'Services',
              style: TextStyle(
                color: Color(0xFF333333),
                fontSize: 24,
                fontFamily: 'Plus Jakarta Sans',
                fontWeight: FontWeight.w300,
                height: 1,
              ),
            ),
          ),
          Container(
            width: width * 0.90,
            margin: EdgeInsets.only(top: height * 0.02, bottom: height * 0.02),
            child: Row(mainAxisAlignment: MainAxisAlignment.start, children: [
              Container(
                  margin:
                      EdgeInsets.only(right: width * 0.02, left: width * 0.02),
                  width: width * 0.18,
                  height: width * 0.18,
                  decoration: ShapeDecoration(
                    color: Colors.white,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10)),
                    shadows: const [
                      BoxShadow(
                        color: Color(0x19161616),
                        blurRadius: 10.47,
                        offset: Offset(0, 2.62),
                        spreadRadius: 0,
                      )
                    ],
                  ),
                  child: Container(
                    padding: EdgeInsets.all(height * 0.005),
                    child: SvgPicture.asset('assets/gas-Logo.svg'),
                  )),
              Container(
                  margin:
                      EdgeInsets.only(right: width * 0.02, left: width * 0.02),
                  width: width * 0.18,
                  height: width * 0.18,
                  decoration: ShapeDecoration(
                    color: Colors.white,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10)),
                    shadows: const [
                      BoxShadow(
                        color: Color(0x19161616),
                        blurRadius: 10.47,
                        offset: Offset(0, 2.62),
                        spreadRadius: 0,
                      )
                    ],
                  ),
                  child: Container(
                    padding: EdgeInsets.all(height * 0.005),
                    child: SvgPicture.asset('assets/water-Logo.svg'),
                  )),
              Container(
                  margin:
                      EdgeInsets.only(right: width * 0.02, left: width * 0.02),
                  width: width * 0.18,
                  height: width * 0.18,
                  decoration: ShapeDecoration(
                    color: Colors.white,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10)),
                    shadows: const [
                      BoxShadow(
                        color: Color(0x19161616),
                        blurRadius: 10.47,
                        offset: Offset(0, 2.62),
                        spreadRadius: 0,
                      )
                    ],
                  ),
                  child: Container(
                      padding: EdgeInsets.all(height * 0.005),
                      child: Icon(
                        Icons.add,
                        color: Color(0xFF393939),
                        size: width * 0.15,
                      ))),
              Container(
                  margin:
                      EdgeInsets.only(right: width * 0.02, left: width * 0.02),
                  width: width * 0.18,
                  height: width * 0.18,
                  decoration: ShapeDecoration(
                    color: Colors.white,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10)),
                    shadows: const [
                      BoxShadow(
                        color: Color(0x19161616),
                        blurRadius: 10.47,
                        offset: Offset(0, 2.62),
                        spreadRadius: 0,
                      )
                    ],
                  ),
                  child: Container(
                      padding: EdgeInsets.all(height * 0.005),
                      child: Icon(
                        Icons.add,
                        color: Color(0xFF393939),
                        size: width * 0.15,
                      ))),
            ]),
          ),
          Container(
              width: width * 0.90,
              margin: EdgeInsets.only(top: height * 0.02, bottom: height * 0.0),
              child: Row(mainAxisAlignment: MainAxisAlignment.start, children: [
                Container(
                    margin: EdgeInsets.only(
                        right: width * 0.02, left: width * 0.02),
                    width: width * 0.18,
                    height: width * 0.18,
                    decoration: ShapeDecoration(
                      color: Colors.white,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                      shadows: const [
                        BoxShadow(
                          color: Color(0x19161616),
                          blurRadius: 10.47,
                          offset: Offset(0, 2.62),
                          spreadRadius: 0,
                        )
                      ],
                    ),
                    child: Container(
                        padding: EdgeInsets.all(height * 0.005),
                        child: Icon(
                          Icons.add,
                          color: Color(0xFF393939),
                          size: width * 0.15,
                        ))),
                Container(
                    margin: EdgeInsets.only(
                        right: width * 0.02, left: width * 0.02),
                    width: width * 0.18,
                    height: width * 0.18,
                    decoration: ShapeDecoration(
                      color: Colors.white,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                      shadows: const [
                        BoxShadow(
                          color: Color(0x19161616),
                          blurRadius: 10.47,
                          offset: Offset(0, 2.62),
                          spreadRadius: 0,
                        )
                      ],
                    ),
                    child: Container(
                        padding: EdgeInsets.all(height * 0.005),
                        child: Icon(
                          Icons.add,
                          color: Color(0xFF393939),
                          size: width * 0.15,
                        ))),
              ]))
        ],
      ),
    );
  }
}

class MyHomePageDevices extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    double width = screenSize.width;
    double height = screenSize.height;
    return Container(
      //Contain all elements
      width: width,
      height: height * 0.31,
      margin: EdgeInsets.only(
        // 5% of the screen width
        right: width * 0.01,
        left: width * 0.01,
        bottom: height * 0.01, // 2.5% of the screen height
      ),
      decoration: ShapeDecoration(
        color: Colors.white,
        shape: RoundedRectangleBorder(
          side: const BorderSide(width: 0.50, color: Color(0x19222222)),
          borderRadius: BorderRadius.circular(5),
        ),
      ),
      child: Column(
        children: [
          Container(
            alignment: Alignment.centerLeft,
            margin: EdgeInsets.all(width * 0.03),
            child: Text(
              'Home Devices',
              style: TextStyle(
                color: Color(0xFF333333),
                fontSize: 24,
                fontFamily: 'Plus Jakarta Sans',
                fontWeight: FontWeight.w300,
                height: 1,
              ),
            ),
          ),
          Container(
            width: width * 0.90,
            margin: EdgeInsets.only(top: height * 0.02, bottom: height * 0.02),
            child: Row(mainAxisAlignment: MainAxisAlignment.start, children: [
              Container(
                  margin:
                      EdgeInsets.only(right: width * 0.02, left: width * 0.02),
                  width: width * 0.18,
                  height: width * 0.18,
                  decoration: ShapeDecoration(
                    color: Colors.white,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10)),
                    shadows: const [
                      BoxShadow(
                        color: Color(0x19161616),
                        blurRadius: 10.47,
                        offset: Offset(0, 2.62),
                        spreadRadius: 0,
                      )
                    ],
                  ),
                  child: Container(
                    padding: EdgeInsets.all(height * 0.005),
                    child: SvgPicture.asset('assets/gas-Logo.svg'),
                  )),
              Container(
                  margin:
                      EdgeInsets.only(right: width * 0.02, left: width * 0.02),
                  width: width * 0.18,
                  height: width * 0.18,
                  decoration: ShapeDecoration(
                    color: Colors.white,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10)),
                    shadows: const [
                      BoxShadow(
                        color: Color(0x19161616),
                        blurRadius: 10.47,
                        offset: Offset(0, 2.62),
                        spreadRadius: 0,
                      )
                    ],
                  ),
                  child: Container(
                    padding: EdgeInsets.all(height * 0.005),
                    child: SvgPicture.asset('assets/water-Logo.svg'),
                  )),
              Container(
                  margin:
                      EdgeInsets.only(right: width * 0.02, left: width * 0.02),
                  width: width * 0.18,
                  height: width * 0.18,
                  decoration: ShapeDecoration(
                    color: Colors.white,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10)),
                    shadows: const [
                      BoxShadow(
                        color: Color(0x19161616),
                        blurRadius: 10.47,
                        offset: Offset(0, 2.62),
                        spreadRadius: 0,
                      )
                    ],
                  ),
                  child: Container(
                      padding: EdgeInsets.all(height * 0.005),
                      child: Icon(
                        Icons.add,
                        color: Color(0xFF58C4BB),
                        size: width * 0.15,
                      ))),
              Container(
                  margin:
                      EdgeInsets.only(right: width * 0.02, left: width * 0.02),
                  width: width * 0.18,
                  height: width * 0.18,
                  decoration: ShapeDecoration(
                    color: Colors.white,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10)),
                    shadows: const [
                      BoxShadow(
                        color: Color(0x19161616),
                        blurRadius: 10.47,
                        offset: Offset(0, 2.62),
                        spreadRadius: 0,
                      )
                    ],
                  ),
                  child: Container(
                      padding: EdgeInsets.all(height * 0.005),
                      child: Icon(
                        Icons.add,
                        color: Color.fromARGB(255, 88, 196, 187),
                        size: width * 0.15,
                      ))),
            ]),
          ),
          Container(
              width: width * 0.90,
              margin: EdgeInsets.only(top: height * 0.02, bottom: height * 0.0),
              child: Row(mainAxisAlignment: MainAxisAlignment.start, children: [
                Container(
                    margin: EdgeInsets.only(
                        right: width * 0.02, left: width * 0.02),
                    width: width * 0.18,
                    height: width * 0.18,
                    decoration: ShapeDecoration(
                      color: Colors.white,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                      shadows: const [
                        BoxShadow(
                          color: Color(0x19161616),
                          blurRadius: 10.47,
                          offset: Offset(0, 2.62),
                          spreadRadius: 0,
                        )
                      ],
                    ),
                    child: Container(
                        padding: EdgeInsets.all(height * 0.005),
                        child: Icon(
                          Icons.add,
                          color: Color(0xFF393939),
                          size: width * 0.15,
                        ))),
                Container(
                    margin: EdgeInsets.only(
                        right: width * 0.02, left: width * 0.02),
                    width: width * 0.18,
                    height: width * 0.18,
                    decoration: ShapeDecoration(
                      color: Colors.white,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                      shadows: const [
                        BoxShadow(
                          color: Color(0x19161616),
                          blurRadius: 10.47,
                          offset: Offset(0, 2.62),
                          spreadRadius: 0,
                        )
                      ],
                    ),
                    child: Container(
                        padding: EdgeInsets.all(height * 0.005),
                        child: Icon(
                          Icons.add,
                          color: Color(0xFF393939),
                          size: width * 0.15,
                        ))),
              ]))
        ],
      ),
    );
  }
}
