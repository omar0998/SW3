import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../controllers/water_controller.dart';

class UtilityBillsWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;

    return PopScope(
      onPopInvoked: (didPop) {
        if (!didPop) {
          // Perform actions before leaving the page
          print("Performing actions before leaving the page");

          // Return true to allow the user to leave the page, or false to prevent it
        }
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 0),
        width: screenSize.width,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            UtilityBillHeader(context, screenSize),
            UtilityBillBody(context, screenSize),
          ],
        ),
      ),
    );
  }

  Widget UtilityBillHeader(BuildContext context, Size screenSize) {
    var electricityController = Provider.of<WaterController>(context);
    final listOfElectricityBills =
        electricityController.waterBillsModel.listOfWaterBills;
    final currIndex = electricityController.currIndex;

    Function nextIndex =
        Provider.of<WaterController>(context, listen: false).nextIndex;
    Function prevIndex =
        Provider.of<WaterController>(context, listen: false).prevIndex;
    print("currIndex");
    print(currIndex);
    return Container(
        margin: const EdgeInsets.only(bottom: 0, top: 0),
        height: screenSize.height * 0.045,
        width: screenSize.width,
        child: FractionallySizedBox(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            mainAxisSize: MainAxisSize.max,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Stack(
                children: [
                  Container(
                    width: screenSize.width * 0.15,
                    height: screenSize.height * 0.045,
                    decoration: const BoxDecoration(
                      color: Color.fromARGB(255, 40, 168, 236),
                      borderRadius:
                          BorderRadius.only(topLeft: Radius.circular(5)),
                    ),
                    child: IconButton(
                      icon: const Icon(
                        Icons.arrow_back,
                        color: Color(0xFF333333),
                      ),
                      onPressed: () {
                        prevIndex();
                      },
                    ),
                  ),
                ],
              ),
              Container(
                width: screenSize.width * 0.665,
                height: 45,
                decoration: const BoxDecoration(
                    color: Color.fromARGB(255, 40, 168, 236),
                    border: Border(
                        right: BorderSide(color: Colors.black26),
                        left: BorderSide(color: Colors.black26))),
                child: Center(
                  child: Text(
                    listOfElectricityBills[currIndex]
                        .invoiceDate
                        .toString()
                        .split(" ")[currIndex],
                    style: const TextStyle(
                      color: Color(0xFF333333),
                      fontSize: 20,
                      fontFamily: 'Plus Jakarta Sans',
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ),
              ),
              Stack(
                children: [
                  Container(
                    width: screenSize.width * 0.15,
                    //height: screenSize.height * 0.045,
                    decoration: const BoxDecoration(
                      color: Color.fromARGB(255, 40, 168, 236),
                      borderRadius:
                          BorderRadius.only(topRight: Radius.circular(7)),
                    ),
                    child: IconButton(
                      icon: const Icon(
                        Icons.arrow_forward,
                        color: Color(0xFF333333),
                      ),
                      onPressed: () {
                        nextIndex();
                      },
                    ),
                  ),
                ],
              ),
            ],
          ),
        ));
  }

  Widget UtilityBillBody(BuildContext context, Size screenSize) {
    var electricityController = Provider.of<WaterController>(context);
    final listOfElectricityBills =
        electricityController.waterBillsModel.listOfWaterBills;
    final currIndex = electricityController.currIndex;
    Function nextIndex =
        Provider.of<WaterController>(context, listen: false).nextIndex;
    Function prevIndex =
        Provider.of<WaterController>(context, listen: false).prevIndex;

    Size screenSize = MediaQuery.of(context).size;

    return Container(
        width: screenSize.width * 0.965,
        //height: screenSize.height * 0.3,
        margin: EdgeInsets.only(bottom: 0, left: 0, right: 0, top: 0),
        decoration: BoxDecoration(
          border: Border(
              right: BorderSide(
                  width: 0.5, color: Color.fromARGB(255, 40, 168, 236)),
// Color of the border
              left: BorderSide(
                width: 0.5,
                color: Color.fromARGB(255, 40, 168, 236),
              ),
              bottom: BorderSide(
                width: 0.5,
                color: Color.fromARGB(255, 40, 168, 236),
              ) // Thickness of the border
              ),
        ),
        child: Column(
          children: [
            Row(
              //Consumption  Value row
              children: [
                Container(
                  height: screenSize.height * 0.025,
                  margin: const EdgeInsets.only(
                      top: 5, left: 10, right: 10, bottom: 0),
                  width: screenSize.width * 0.9,
                  child: Stack(
                    children: [
                      Container(
                        child: const Text(
                          'Water Consumption Quantity\n',
                          style: TextStyle(
                            color: Color(0xFF333333),
                            fontSize: 14,
                            fontFamily: 'Inter',
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                      ),
                      Container(
                        alignment: Alignment.centerRight,
                        child: Text(
                          '${electricityController.waterBillsModel.listOfWaterBills[currIndex].waterConsumptionQuantity} Meter Cubed\n',
                          style: const TextStyle(
                            color: Color(0xFF333333),
                            fontSize: 14,
                            fontFamily: 'Inter',
                            fontWeight: FontWeight.w300,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            Row(
              //Curr. Meter row
              children: [
                Container(
                  height: screenSize.height * 0.020,
                  margin: const EdgeInsets.only(
                      top: 0, left: 10, right: 10, bottom: 0),
                  width: screenSize.width * 0.9,
                  child: Stack(
                    children: [
                      Container(
                        child: const Text(
                          'Water Curr. Meter Reading\n',
                          style: TextStyle(
                            color: Color(0xFF858585),
                            fontSize: 10,
                            fontFamily: 'Inter',
                            fontWeight: FontWeight.w300,
                          ),
                        ),
                      ),
                      Container(
                        alignment: Alignment.centerRight,
                        child: Text(
                          '${electricityController.waterBillsModel.listOfWaterBills[currIndex].waterCurrentMeterReading}',
                          style: const TextStyle(
                            color: Color(0xFF858585),
                            fontSize: 10,
                            fontFamily: 'Inter',
                            fontWeight: FontWeight.w300,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            Row(
              //Consumption  Value row
              children: [
                Container(
                  margin: const EdgeInsets.only(top: 0, left: 10, right: 10),
                  width: screenSize.width * 0.9,
                  height: screenSize.height * 0.025,
                  child: Stack(
                    children: [
                      Container(
                        child: const Text(
                          'Water Prev. Meter Reading',
                          style: TextStyle(
                            color: Color(0xFF858585),
                            fontSize: 10,
                            fontFamily: 'Inter',
                            fontWeight: FontWeight.w300,
                          ),
                        ),
                      ),
                      Container(
                        alignment: Alignment.centerRight,
                        child: Text(
                          '${electricityController.waterBillsModel.listOfWaterBills[currIndex].waterPreviousMeterReading}',
                          style: TextStyle(
                            color: Color(0xFF858585),
                            fontSize: 10,
                            fontFamily: 'Inter',
                            fontWeight: FontWeight.w300,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            Container(
              //Separation Line
              width: screenSize.width,
              margin: const EdgeInsets.only(top: 5, bottom: 5),
              decoration: const ShapeDecoration(
                shape: RoundedRectangleBorder(
                  side: BorderSide(
                    width: 0.50,
                    strokeAlign: BorderSide.strokeAlignCenter,
                    color: Color(0xFFE9E9E9),
                  ),
                ),
              ),
            ),
            Row(
              //Consumption Amount row
              children: [
                Container(
                  margin: const EdgeInsets.only(top: 20, left: 10, right: 10),
                  width: screenSize.width * 0.9,
                  child: Stack(
                    children: [
                      Container(
                        child: const Text(
                          'Consumption Value\n',
                          style: TextStyle(
                            color: Color(0xFF333333),
                            fontSize: 14,
                            fontFamily: 'Inter',
                            fontWeight: FontWeight.w400,
                            height: 0.09,
                          ),
                        ),
                      ),
                      Container(
                        alignment: Alignment.centerRight,
                        child: Text(
                          '${electricityController.waterBillsModel.listOfWaterBills[currIndex].waterConsumptionValue} SAR\n',
                          style: const TextStyle(
                            color: Color(0xFF333333),
                            fontSize: 14,
                            fontFamily: 'Inter',
                            fontWeight: FontWeight.w300,
                            height: 0.09,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            Container(
              //Separation Line
              width: screenSize.width,
              margin: const EdgeInsets.only(top: 15, bottom: 5),
              decoration: const ShapeDecoration(
                shape: RoundedRectangleBorder(
                  side: BorderSide(
                    width: 0.50,
                    strokeAlign: BorderSide.strokeAlignCenter,
                    color: Color(0xFFE9E9E9),
                  ),
                ),
              ),
            ),
            Row(
              //Meter Rent row
              children: [
                Container(
                  margin: const EdgeInsets.only(top: 20, left: 10, right: 10),
                  width: screenSize.width * 0.9,
                  child: Stack(
                    children: [
                      Container(
                        child: const Text(
                          'Service Fee\n',
                          style: TextStyle(
                            color: Color(0xFF333333),
                            fontSize: 14,
                            fontFamily: 'Inter',
                            fontWeight: FontWeight.w400,
                            height: 0.09,
                          ),
                        ),
                      ),
                      Container(
                        alignment: Alignment.centerRight,
                        child: Text(
                          '${electricityController.waterBillsModel.listOfWaterBills[currIndex].serviceFee} SAR\n',
                          style: TextStyle(
                            color: Color(0xFF333333),
                            fontSize: 14,
                            fontFamily: 'Inter',
                            fontWeight: FontWeight.w300,
                            height: 0.09,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            Container(
              //Separation Line
              width: screenSize.width,
              margin: const EdgeInsets.only(top: 15, bottom: 5),
              decoration: const ShapeDecoration(
                shape: RoundedRectangleBorder(
                  side: BorderSide(
                    width: 0.50,
                    strokeAlign: BorderSide.strokeAlignCenter,
                    color: Color(0xFFE9E9E9),
                  ),
                ),
              ),
            ),
            Row(
              //Total Before VAT Amount row
              children: [
                Container(
                  margin: const EdgeInsets.only(top: 15, left: 10, right: 10),
                  width: screenSize.width * 0.9,
                  child: Stack(
                    children: [
                      Container(
                        child: const Text(
                          'Total Amount Before VAT\n',
                          style: TextStyle(
                            color: Color(0xFF333333),
                            fontSize: 14,
                            fontFamily: 'Inter',
                            fontWeight: FontWeight.w400,
                            height: 0.09,
                          ),
                        ),
                      ),
                      Container(
                        alignment: Alignment.centerRight,
                        child: Text(
                          '${electricityController.waterBillsModel.listOfWaterBills[currIndex].totalValueBeforeVat} SAR\n',
                          style: const TextStyle(
                            color: Color(0xFF333333),
                            fontSize: 14,
                            fontFamily: 'Inter',
                            fontWeight: FontWeight.w300,
                            height: 0.09,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            Container(
              //Separation Line
              width: screenSize.width,
              margin: const EdgeInsets.only(top: 15, bottom: 5),
              decoration: const ShapeDecoration(
                shape: RoundedRectangleBorder(
                  side: BorderSide(
                    width: 0.50,
                    strokeAlign: BorderSide.strokeAlignCenter,
                    color: Color(0xFFE9E9E9),
                  ),
                ),
              ),
            ),
            Row(
              ////VAT Amount row
              children: [
                Container(
                  margin: const EdgeInsets.only(top: 20, left: 10, right: 10),
                  width: screenSize.width * 0.9,
                  child: Stack(
                    children: [
                      Container(
                        child: const Text(
                          'VAT Amount (15%)\n',
                          style: TextStyle(
                            color: Color(0xFF333333),
                            fontSize: 14,
                            fontFamily: 'Inter',
                            fontWeight: FontWeight.w400,
                            height: 0.09,
                          ),
                        ),
                      ),
                      Container(
                        alignment: Alignment.centerRight,
                        child: Text(
                          '${electricityController.waterBillsModel.listOfWaterBills[currIndex].vat} SAR\n',
                          style: const TextStyle(
                            color: Color(0xFF333333),
                            fontSize: 14,
                            fontFamily: 'Inter',
                            fontWeight: FontWeight.w300,
                            height: 0.09,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            Container(
              //Separation Line
              width: screenSize.width,
              margin: const EdgeInsets.only(top: 15, bottom: 5),
              decoration: const ShapeDecoration(
                shape: RoundedRectangleBorder(
                  side: BorderSide(
                    width: 0.50,
                    strokeAlign: BorderSide.strokeAlignCenter,
                    color: Color(0xFFE9E9E9),
                  ),
                ),
              ),
            ),
            Row(
              //Meter Rent row
              children: [
                Container(
                  margin: const EdgeInsets.only(
                      top: 20, left: 10, right: 10, bottom: 15),
                  width: screenSize.width * 0.9,
                  child: Stack(
                    children: [
                      Container(
                        child: const Text(
                          'Total Amount\n',
                          style: TextStyle(
                            color: Color(0xFF333333),
                            fontSize: 14,
                            fontFamily: 'Inter',
                            fontWeight: FontWeight.bold,
                            height: 0.09,
                          ),
                        ),
                      ),
                      Container(
                        alignment: Alignment.centerRight,
                        child: Text(
                          '${electricityController.waterBillsModel.listOfWaterBills[currIndex].totalValueAfterVat} SAR\n',
                          style: const TextStyle(
                            color: Color(0xFF333333),
                            fontSize: 14,
                            fontFamily: 'Inter',
                            fontWeight: FontWeight.w300,
                            height: 0.09,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ));
  }
}
