import 'package:flutter/material.dart';
import '../home_view.dart';

class bottomBar extends StatelessWidget {
  const bottomBar({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width, // Set to full screen width
      height: 90,
      decoration: const BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Color(0x3F000000),
            blurRadius: 4,
            offset: Offset(0, 4),
            spreadRadius: 0,
          )
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          GestureDetector(
            onTap: () {
              // Navigate to the HomeView() when the 'Home' tab is clicked
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => HomeView()),
              );
            },
            child: _buildTab(
              'Home',
              Color(0xFF58C4BB),
              Icon(Icons.home, color: Color(0xFF58C4BB)),
            ),
          ),
          GestureDetector(
            onTap: () {
              // Call the function of your choice when the 'Orders' tab is clicked
              HomeView();
            },
            child: _buildTab(
              'Orders',
              Color(0xFF393939),
              Icon(Icons.delivery_dining, color: Color(0xFF393939)),
            ),
          ),
          GestureDetector(
            onTap: () {
              // Call the function of your choice when the 'Family' tab is clicked
              HomeView();
            },
            child: _buildTab(
              'Family',
              Color(0xFF393939),
              Icon(Icons.family_restroom, color: Color(0xFF393939)),
            ),
          ),
          GestureDetector(
            onTap: () {
              // Call the function of your choice when the 'Notifications' tab is clicked
              HomeView();
            },
            child: _buildTab(
              'Notifications',
              Color(0xFF393939),
              Icon(Icons.notifications, color: Color(0xFF393939)),
            ),
          ),
          GestureDetector(
            onTap: () {
              // Call the function of your choice when the 'More' tab is clicked
              HomeView();
            },
            child: _buildTab(
              'More',
              Color(0xFF393939),
              Icon(Icons.more_horiz_sharp, color: Color(0xFF393939)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTab(String text, Color textColor, Icon icon) {
    return SizedBox(
      width: 70.99,
      height: 55,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          icon, // Wrap the icon with an Icon widget
          Text(
            text,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: textColor,
              fontSize: 10.36,
              fontFamily: 'Lato',
              fontWeight: FontWeight.w500,
              letterSpacing: 0.10,
            ),
          ),
        ],
      ),
    );
  }
}
