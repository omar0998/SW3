// import 'package:flutter/material.dart';
// import 'package:webview_flutter/webview_flutter.dart';

// class WebViewExample extends StatefulWidget {
//   const WebViewExample({super.key});

//     @override
//     _WebViewExampleState createState() => _WebViewExampleState();
//   }
  
//   class _WebViewExampleState extends State<WebViewExample> {
//     late final WebViewController webViewController;
  
//     @override
//     void initState() {
//       // WebViewSe settings = yourWebview.getSettings();
//       // settings.setJavaScriptEnabled(true);

//       webViewController = WebViewController(
//       )
//       ..setNavigationDelegate(
//       NavigationDelegate( 
//         onPageStarted: (String url) {
//           print("Start");
//           },
//         onPageFinished: (String url) {
//           print("Page Finished");
//           // _JsCode();
//         },
//       ))
//       // ..setJavaScriptMode(JavaScriptMode.unrestricted) 
//       ..setOnConsoleMessage((message) {
//         debugPrint("Console Message: ${message.message}");
//       })
//       // ..addJavaScriptChannel("JS MESSAGES", onMessageReceived: (JavaScriptMessage jmsg){
//       //   print(jmsg.message);
//       // } )
//       ..loadRequest(
//         Uri.parse('https://ebranch.nwc.com.sa/Arabic/Pages/Login.aspx'),
//         );

//       super.initState();
//     }


//     @override
//     Widget build(BuildContext context) {
//       return Scaffold(
//         appBar: AppBar(
//           title: Text('WebView Example'),
//         ),
//         body:
//         WebViewWidget(controller: webViewController,  )

//       );
//     }

//     Future<void> _JsCode() {
    
//     return webViewController.runJavaScript(
   
//     """
//       (function() {
//         console.log("Hello");

//         var proxiedOpen = XMLHttpRequest.prototype.open;
//         XMLHttpRequest.prototype.open = function() {
//           console.log("Hi");

//           console.log('Request URL:', arguments[1]);
//           console.log('Request Cookies:', document.cookie);

//           this.addEventListener('load', function() {
//             console.log('Response:', this.responseText);
//           });

//           // Add other logging or interception logic
//           // return proxiedOpen.apply(this, arguments);

//         };
//       }

//       )();"""
    

//     );
//     }
//   }