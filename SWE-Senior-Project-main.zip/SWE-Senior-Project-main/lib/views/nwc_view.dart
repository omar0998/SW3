import 'package:flutter/material.dart';
import 'package:flutter_app/controllers/electricity_controller.dart';
import 'package:flutter_app/models/electricity_bills.dart';
import 'package:flutter_app/views/components/nwcChart.dart';
import 'package:flutter_app/views/components/NWCwidgets.dart';
import 'package:flutter_app/views/components/myAppBar.dart';
import 'package:provider/provider.dart';

import '../controllers/home_controller.dart';

class WaterView extends StatefulWidget {
  const WaterView({Key? key}) : super(key: key);

  @override
  _WaterViewState createState() => _WaterViewState();
}

class _WaterViewState extends State<WaterView> {
  // int _currentIndex = 0;

  // int _currentIndex = 0;
  bool isLoading = false;

  @override
  Widget build(BuildContext context) {
    final currentRoute = ModalRoute.of(context)?.settings.name;
    print('Currently on route: $currentRoute');
    var electricityController = Provider.of<ElectricityController>(context);
    Size screenSize = MediaQuery.of(context).size;

    return Scaffold(
        appBar: const MyAppBar(),
        body: SafeArea(
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
              // const Divider(height: 50,color: Colors.white,),

              const MyHomePage(title: 'Electricity Statistics Page'),
              // const Divider(height: 50,color: Colors.white,),
              Container(
                  width: screenSize.width,
                  alignment: Alignment.center,
                  //margin: EdgeInsets.all(10),
                  child: Column(
                    children: [UtilityBillsWidget()],
                  ))
            ])));
  }
}
