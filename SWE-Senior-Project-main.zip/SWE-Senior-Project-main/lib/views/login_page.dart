import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'components/my_button.dart';
import 'components/textfiled.dart';


class LoginPage extends StatefulWidget {
  final Function()? onTap;
  const LoginPage({super.key, required this.onTap});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final emailController = TextEditingController();
  // Remove const here
  final passwordController = TextEditingController();
  // Remove const here

  void signUserIn() async {
    // show loading circle
    showDialog(
      context: context,
      builder: (context) {
        return const Center(
          child: CircularProgressIndicator(),
        );
      },
    );

    try {
      await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: emailController.text,
        password: passwordController.text,
      );
      Navigator.pop(context);
    } on FirebaseAuthException catch (e) {
      Navigator.pop(context);

      showErrorMessage(e.code);
    }

    // pop the loading circle once user logged in
  }

  // message for invalid credentials
  // Wrong email message popup
  void showErrorMessage(String message) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          backgroundColor: Colors.deepPurple,
          title: Center(
            child: Text(
              message,
              style: const TextStyle(color: Colors.white),
            ),
          ),
          // Add an "OK" button to dismiss the dialog
          actions: [
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('OK'),
            ),
          ],
        );
      },
    );
  }

  // sign user Up method
  void signUserUp() {}

  @override
  Widget build(context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: const Color.fromARGB(255, 229, 227, 227),
        body: Center(
          child: Column(
            children: [
              // size box for the space
              const SizedBox(
                height: 50,
              ),
              // lock icon ( logo )
              const Icon(
                Icons.lock,
                size: 180,
              ),
              // Size box for the space
              const SizedBox(
                height: 20,
              ),
              const Text(
                "let's create an account for you",
                style: TextStyle(color: Colors.grey, fontSize: 20),
              ),
              // size box for the space
              const SizedBox(
                height: 20,
              ),
              // enter the email
              MyTextfiled(
                controller: emailController,
                hinttext: "Email",
                obsecur: false,
              ),
              // size box for the space
              const SizedBox(
                height: 20,
              ),
              // enter the password
              MyTextfiled(
                controller: passwordController,
                hinttext: "Password",
                obsecur: true,
              ),
              // forgetting password with some padding into the left
              const Padding(
                padding: EdgeInsets.all(8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Text(
                      "Forgot Password?",
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
              const SizedBox(
                height: 20,
              ),
              MyButton(
                text: "Sign In",
                onTap: signUserIn,
              ),
              const SizedBox(
                height: 20,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'Not a member?',
                    style: TextStyle(color: Colors.grey[700]),
                  ),
                  const SizedBox(width: 4),
                  GestureDetector(
                    onTap: widget.onTap,
                    child: const Text(
                      'Register now',
                      style: TextStyle(
                        color: Colors.blue,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}