import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_app/models/user.dart' as u;
import 'package:provider/provider.dart';
import '../controllers/electricity_controller.dart';
import 'components/bottomBar.dart';
import '../controllers/home_controller.dart';
import 'components/homePageWidgets.dart';

class HomeView extends StatefulWidget {
  const HomeView({Key? key}) : super(key: key);
  @override
  _HomeViewState createState() => _HomeViewState();
}

class _HomeViewState extends State<HomeView> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Color.fromARGB(255, 249, 249, 249),
        body: SafeArea(
          child: Column(
            children: [
              Expanded(
                  child: ChangeNotifierProvider<HomeController>(
                create: (context) => HomeController(),
                child: ListView.builder(
                  itemCount: 1, // Set the item count to 1
                  itemBuilder: (BuildContext context, int index) {
                    return AutoLayoutVertical();
                  },
                ),
              )),
            ],
          ),
        ),
        bottomNavigationBar: const bottomBar());
  }
}

class AutoLayoutVertical extends StatelessWidget {
  const AutoLayoutVertical({super.key});

  @override
  Widget build(BuildContext context) {
    // var homeController = Provider.of<HomeController>(context);
    var electricityController = Provider.of<ElectricityController>(context);

     // Access the userModel using Provider
    var userModel = Provider.of<u.User>(context);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        MyHomePageTopPicture(),
        MyHomePageBills(),
        MyHomePageServices(),
        MyHomePageDevices()
      ],
    );
  }
}
